let students = [
    {regNo:'2021ICT28', name:'Gawesha', age:24, course:'IT', gender:'female'},
    {regNo:'2021ICT11', name:'ransi', age:23, course:'IT', gender:'female'},
    {regNo:'2021ABS01', name:'kavee', age:21, course:'Bio', gender:'female'},
    {regNo:'2021AMC82', name:'Haran', age:23, course:'AMC', gender:'male'},
    {regNo:'2021ICT23', name:'janu', age:22, course:'IT', gender:'female'}
   ];

   module.exports = students;