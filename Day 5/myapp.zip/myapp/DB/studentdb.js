
let students=[
    {regno:'2021ICT28',name:'Gawesha',gender:'female',age:25,course:'IT'},
    {regno:'2021ICT01',name:'nike',gender:'male',age:20,course:'IT'},
    {regno:'2021ICT23',name:'grace',gender:'female',age:21,course:'IT'},
    {regno:'2021ICT11',name:'temiya',gender:'male',age:24,course:'Bio'},
    {regno:'2021ICT05',name:'rooso',gender:'male',age:22,course:'Maths'}
    ];

module.exports=students;